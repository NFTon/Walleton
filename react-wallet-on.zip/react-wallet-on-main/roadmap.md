# Basic Web Examples

Basic examples/templates for using WalletConnect SDKs

## Table Of Contents:

```bash
.
├── dapps/
│   ├── web3modal
│   ├── web3inbox(TODO)
│   ├── ethereum-provider
│   ├── universal-provider-solana
│   └── universal-provider-cosmos(TODO)
└── wallets/
    ├── web3wallet(TODO)
    ├── web3wallet-ethers(TODO)
    ├── web3wallet-viem(TODO)
    └── web3wallet-wagmi(TODO)
```
