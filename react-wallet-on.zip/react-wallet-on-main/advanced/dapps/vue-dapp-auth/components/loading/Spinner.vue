<template>
  <div class="tw-flex tw-justify-center tw-items-center">
    <div class="tw-spinner-border tw-animate-spin tw-inline-block tw-circle-[1em] tw-border-[3px] tw-border-base tw-border-opacity-muted tw-border-l-transparent" role="status">
      <span class="tw-hidden">Loading...</span>
    </div>
  </div>
</template>
