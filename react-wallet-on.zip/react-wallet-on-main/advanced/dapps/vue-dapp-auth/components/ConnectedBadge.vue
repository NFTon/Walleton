<template>
  <div class="tw-text-dim-2 tw-inline-flex tw-items-center tw-gap-2">
    <span class="tw-relative tw-circle-[0.5em] tw-bg-state-success tw-inline-flex before:tw-circle-[0.5em] before:tw-scale-[1.2] before:tw-bg-state-success before:tw-animate-ping before:tw-opacity-soft before:tw-absolute" />
    Connected
  </div>
</template>
